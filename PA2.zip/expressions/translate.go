// translate.go
// Morgan Barksdale
// CS 240 - Fox
// 10/13/13

package expressions

import (
	"containers"
	"errors"
)

/* Passes the expression through an error check
and then passes it to the appropriate translation function*/
func Translate(s string) (string, error) {

	// set variables
	var result containers.Stack
	var value containers.AnyType = ""

	// check for malformed expression
	err := checkExpression(s)

	// call translate function
	if (err == nil) {
		initial_stack := containers.NewLinkedStack()
		for i := len(s)-1; i >=0; i-- {
			initial_stack.Push(string(s[i]))
		}

		if (IsPrefix(s)) {
			result = translatePrefixRecursive(containers.NewLinkedStack(), initial_stack)
		} else {
			result = translateInfixRecursive(containers.NewLinkedStack(), initial_stack)
		}

		value, err = result.Pop()
	}

	return value.(string), err 
}


/* Recursively translates prefix to postfix */
func translatePrefixRecursive(left, right containers.Stack) containers.Stack {

	// base condition
	if right.Size() == 1 {
		return right
	}

	// variables
	v, err := right.Pop()
	consecutive := false

	// go through "right" stack once
	for err == nil {

		if isOperatorString(v.(string)) {
			left.Push(v.(string))
			consecutive = false
		} else {
			if consecutive {
				operand, err := left.Pop()
				if err != nil { return containers.NewLinkedStack() }
				operator, err := left.Pop()
				if err != nil { return containers.NewLinkedStack() }
				left.Push( operand.(string) + v.(string) + operator.(string) )
				consecutive = false
			} else {
				left.Push(v.(string))
				consecutive = true
			}
		}

		v, err = right.Pop()
	}

	// recursion!
	return translatePrefixRecursive(right, reverseStack(left))
}

/* Recursively translates infix to postfix */
func translateInfixRecursive(left, right containers.Stack) containers.Stack {

	// base condition
	if right.Size() == 1 {
		return right
	}

	// variables
	v, err := right.Pop()
	seq := ""

	// go through "right" stack once
	for err == nil {

		if isOperatorString(v.(string)) {
			left.Push(v.(string))
			seq += "o"
		} else if v.(string) == "(" {
			left.Push(v.(string))
			seq += "l"
		} else if v.(string) == ")" {
			if len(seq) >= 2 {
				if seq[len(seq)-2:] == "ln" {
					operand, err := left.Pop()
					if err != nil { return containers.NewLinkedStack() }
					_, err = left.Pop()
					if err != nil { return containers.NewLinkedStack() }
					left.Push( operand.(string) )
					seq = seq[:len(seq)-2]
					seq += "n"
				} else {
					left.Push(v.(string))
					seq += "r"
				}
			} else {
				left.Push(v.(string))
				seq += "r"
			}
		} else {
			if len(seq) >= 2 {
				if seq[len(seq)-2:] == "no" {
					operator, err := left.Pop()
					if err != nil { return containers.NewLinkedStack() }
					operand, err := left.Pop()
					if err != nil { return containers.NewLinkedStack() }
					left.Push( operand.(string) + v.(string) + operator.(string) )
					seq = seq[:len(seq)-1]
				} else {
					left.Push(v.(string))
					seq += "n"
				}
			} else {
				left.Push(v.(string))
				seq += "n"
			}
		}

		v, err = right.Pop()
	}

	// recursion!
	return translateInfixRecursive(right, reverseStack(left))
}

// there might be a better way to do this
// reverses stack
func reverseStack(stack containers.Stack) (containers.Stack) {
	newStack := containers.NewLinkedStack()
	v, err := stack.Pop()

	// take all elements from stack
	for err == nil {
		// and put them in newStack
		newStack.Push(v)
		v, err = stack.Pop()
	}

	return newStack
}

// looks for problems with the expression
func checkExpression(s string) error {

	// variables
	prefix := IsPrefix(s)
	current := NewTokenizer(s)
	digits, operators, parens := 0, 0, 0

	// check for illegal characters
	for current.Char != '$' {
		if (isDigit(current.Char)) {
			digits++
		} else if isOperator(current.Char) {
			operators++
		} else if isParenthesis(current.Char) && !prefix {
			if (current.Char == '(') {
				parens += 1
			} else {
				parens -= 1
			}
			// check parenthesis alignment
			if (parens < 0) {
				return errors.New("Missing left parenthesis")
			}
		} else {
			return errors.New("Illegal character")
		}

		current.Next()
	}

	// check parenthesis alignment
	if (parens > 0) {
		return errors.New("Missing right parenthesis")
	}

	// check number of operands/operators
	if (digits - operators) > 1 {
		return errors.New("Missing operator")
	} else if (digits - operators) < 1 {
		return errors.New("Missing argument")
	}

	return nil
}
