// eval.go: This file contains recursive and stack-based algorithms for
// evaluating simple and postfix expressions held in strings. These
// expressions must have only the operators +, -, *, /, and % (with
// their usual meanings in integer arithemetic), and operands that
// are one digit long. There are no negative operands.
// No white space is allowed in expressions.

package expressions

import (
	"containers"
	"errors"
	"fmt"
	"strings"
)

////////////////////////////////////////////////////////////////////////////
// Expression evaluation utility functions.

func IsPrefix(s string) bool {
	if isOperator(s[0]) {
		return true
	}
	return false
}

// Determine whether a character is a digit
func isDigit(ch byte) bool {
	return strings.ContainsRune("0123456789", rune(ch))
}

// Determine whether a character is an operator
func isOperator(ch byte) bool {
	return strings.ContainsRune("+-*/%", rune(ch))
}

func isOperatorString(s string) bool {
	return strings.ContainsRune("+-*/%", rune(s[0]))
}

func isParenthesis(ch byte) bool {
	return strings.ContainsRune("()", rune(ch))
}

func isParenthesisString(s string) bool {
	return strings.ContainsRune("()", rune(s[0]))
}

// Apply an operator designated by op to two arguments
func applyOperator(op byte, leftArg, rightArg int) (int, error) {
	switch op {
	case '+':
		return leftArg + rightArg, nil
	case '-':
		return leftArg - rightArg, nil
	case '*':
		return leftArg * rightArg, nil
	case '/':
		return leftArg / rightArg, nil
	case '%':
		return leftArg % rightArg, nil
	default:
		return 0, errors.New(fmt.Sprintf("Bad character %c", op))
	}
	panic("Reached impossible spot")
}

//////////////////////////////////////////////////////////////////////////
// Postfix: These functions evaluate a postfix expression held in a string.

// EvalPostfixRecursive uses recursion to parse and evaluate a postfix
// expression.
// Pre: The expression in s is well formed
// Pre violation: return 0 and an error indication
// Normal return: the expression value and nil
func EvalPostfixRecursive(s string) (int, error) {
	current := NewTokenizer(s)
	result, err := evalPostfix(current)
	if err == nil && current.Char != '$' {
		return 0, errors.New("Extra characters at the end of the expression")
	}
	return result, err
}

// evalPostfix is a private function that recursively parses and evaluates
// a postfix expression provided by a Tokenizer.
// Strategy: The first character must be a digit, so remember it as the leftArg.
// Assume the next digit is the rightArg. If the character after that is not an
// operator, then back up one character and call evalPostfix recursively to
// evaluate the right operand expression. When the operator is finally found,
// apply it to leftArg and rightArg and leave the result in leftArg. Look for
// another digit as the start of a possible following expression and repeat.
func evalPostfix(current *Tokenizer) (result int, err error) {
	if !isDigit(current.Char) {
		return 0, errors.New("Missing argument")
	}
	leftArg := int(current.Char - '0')
	current.Next()
	for isDigit(current.Char) {
		rightArg := int(current.Char - '0')
		current.Next()
		if current.Char == '$' {
			return 0, errors.New("Missing operator")
		}
		if isDigit(current.Char) {
			current.Last()
			for {
				if rightArg, err = evalPostfix(current); err != nil {
					return 0, err
				}
				if !isDigit(current.Char) { break }
			}
		}
		if leftArg, err = applyOperator(current.Char, leftArg, rightArg); err != nil {
			return 0, err
		}
		current.Next()
	}
	return leftArg, nil
}

// EvalPostfixStack uses a stack to parse and evaluate a postfix expression.
// Pre: The expression in s is well formed
// Pre violation: return 0 and an error indication
// Normal return: the expression value and nil
// Strategy: Put all operands in the stack, and whenever an operator is
// encountered, apply it to the top two values in the stack and push the
// result back on the stack. At the end, the stack should contain the result.
func EvalPostfixStack(s string) (int, error) {
	current := NewTokenizer(s)
	stack := containers.NewLinkedStack()
	for current.Char != '$' {
		if isDigit(current.Char) {
			stack.Push(int(current.Char - '0'))
		} else {
			rightArg, err := stack.Pop()
			if err != nil {
				return 0, errors.New("Missing right argument")
			}
			leftArg, err := stack.Pop()
			if  err != nil {
				return 0, errors.New("Missing left argument")
			}
			if value, err := applyOperator(current.Char, leftArg.(int), rightArg.(int)); err == nil {
				stack.Push(value)
			} else {
				return 0, err
			}
		}
		current.Next()
	}
	result, err := stack.Pop()
	if err != nil {
		return 0, errors.New("Missing expression")
	}
	if !stack.IsEmpty() {
		return 0, errors.New("Too many arguments")
	}
	return result.(int), nil
}
