// evaluate.go
// Morgan Barksdale
// CS 240 - Fox
// 10/13/13

package main

import (
	"PA2/expressions"
	"fmt"
)

// runs the main input/eval loop
func main() {
	// variables
	n := 1

	fmt.Printf("Infix or prefix expression evaluator.")

	// while the user hasn't entered just a return
	for n != 0 {

		// variables
		input := ""
		var err error = nil

		// print prompt
		fmt.Printf("\n>")

		// get input
		n, err = fmt.Scanf("%s", &input)

		// halt if error occurred
		if err != nil {
			break
		}

		// initialize result variable
		result := ""

		// call translation routine
		result, err = expressions.Translate(input)

		// halt if error occurred
		if err != nil {
			fmt.Printf("%v", err)
		} else {
			answer, err := expressions.EvalPostfixRecursive(result)
			if (err == nil) {
				fmt.Printf("Evaluating %s -> %d", result, answer)
			} else {
				fmt.Printf("%v\n", err)
			}
		}

	}

	fmt.Printf("Bye\n")
}
